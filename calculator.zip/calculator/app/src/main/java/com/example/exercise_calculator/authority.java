package com.example.exercise_calculator;

public class authority {
    static private  authority singletonInstance;
    private String name1;
    private String name2;
    static public authority getInstance(){
        if(singletonInstance == null){
            singletonInstance = new authority();
        }
        return singletonInstance;
    }
    private authority(){
        name1 = "Taogonglin";
        name2 = "Wanglongxiang";
    }
    public String getName1(){
        return name1;
    }
    public  String getName2(){
        return name2;
    }
}
